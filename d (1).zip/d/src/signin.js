import React from "react";
import Button from '@mui/material/Button';

var Sign=()=>{
    
    return(
       
        
        <div id="div2">
            <center>
            {/*<div style={{backgroundImage: 'url("https://wallpaperaccess.com/full/254472.jpg")'}}></div>  */}         
            <u><h1>SIGN-UP PAGE</h1></u><br></br>
            Username:<input type="text"></input><br></br><br></br>
            Password:<input type="text"></input><br></br><br></br>
            <h2>Forgot Password</h2>
            <Button variant="contained" href="/Login">Signin</Button>   
            
            </center>
        </div>
    
    )
}
export default Sign;