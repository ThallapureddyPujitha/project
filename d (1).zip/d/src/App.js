import Path from "./linking";
import './App.css';

function App() {
  return (
    <div>
    <Path/>
    </div>
  );
}

export default App;
