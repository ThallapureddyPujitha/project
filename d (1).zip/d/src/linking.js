import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Sign from "./signin";
import Logining from "./login";
import Home from "./home";
import About from "./about";
import Contact from "./contact";
import Logout from "./logout";
import ButtonAppBar from "./flight";

let Path=()=>{
    return(
        <BrowserRouter>
        <Routes>
            <Route path="/" element={<Sign/>}></Route>
            <Route path="/Login" element={<Logining/>}></Route>
            <Route  path="/Home" element={<Home/>}></Route>
            <Route path="/About" element={<About/>}></Route>
            <Route path="/Contact" element={<Contact/>}></Route>
            <Route path="/logout" element={<Logout/>}></Route>
            <Route path="/Sign" element={<Sign/>}></Route>
            <Route path="/flight" element={<ButtonAppBar/>}></Route>
            
            
        </Routes>
        </BrowserRouter>
    )
}
export default Path;