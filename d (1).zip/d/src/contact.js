import React, { useState } from "react";
import { SiYourtraveldottv } from "react-icons/si";
import { useNavigate } from "react-router-dom";
import Button from '@mui/material/Button';


const Contact = () => {
  const n = useNavigate();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");

  const GoHome = () => {
    n("/");
  };

  const GoAbout = () => {
    n("/About");
  };
  const GoContact = () => {
    n("/Contact");
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const data = {
      name,
      email,
      message,
    };
    console.log(data); // Example of handling form submission, you can modify this based on your needs
  };

  return (
    <div id="div1">
      <header>
        <nav>
          <ul>
            <li>
              <SiYourtraveldottv className="icon" />
            </li>
            <li onClick={GoHome}>HOME</li>
            <li onClick={GoAbout}>ABOUT</li>
            <li onClick={GoContact}>CONTACT</li>
          </ul>
        </nav>
      </header>
      <center>
      <h1>Contact Us</h1>
      <p>Please fill out the form below to contact us.</p>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="name"
          placeholder="Your Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <br />
        <br />
        <input
          type="email"
          name="email"
          placeholder="Your Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <br />
        <br />
        <textarea
          name="message"
          placeholder="Your Message"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
        />
        <br />
        <Button variant="contained" href="/Logout">Submit</Button>
      </form>
      <p>
        <strong>About Us</strong>
        <br />
        We are a company that provides flight ticket booking services. We offer
        a wide variety of flights to destinations all over the world.
      </p>
      <p>
        <strong>Contact Information</strong>
        <br />
        Email: support@example.com
        <br />
        Phone: 123-456-7890
      </p>
      </center>
    </div>
  );
};

export default Contact;
