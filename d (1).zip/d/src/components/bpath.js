import React from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import flight from './flight';
const Bpath = () => {
  return (
    <BrowserRouter>
    <Routes>
        <Route path="/flight" element={<flight/>}></Route>
    </Routes>
    </BrowserRouter>
  )
}

export default Bpath
