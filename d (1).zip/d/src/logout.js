import { useState } from "react";
import { SiYourtraveldottv } from "react-icons/si";
import { useNavigate } from "react-router-dom";
import Button from '@mui/material/Button';
let Logout=()=>{
const n=useNavigate();
    let GoHome=()=>{
        n('/')
    }
    let GoAbout=()=>{
        n('/About')
    }
    let GoContact=()=>{
        n('/Contact')
    }
    let Change=()=> {
        if(password==" " || email==""){
        alert("fill the empty fields")
      }
        }
      let [email, setEmail] = useState('');
      let [password, setPassword] = useState('');
      let [Login]=useState(' ');
      const handleSubmit = (e) => {
        e.preventDefault();
        // Handle login logic here
        console.log('Email:', email);
        console.log('Password:', password);
        // Reset form fields
        setEmail('');
        setPassword(''); 
      }
    return(
        <div className='back'>
        <div id="div1">
            <header>
                <nav>
                <ul>
                <li><SiYourtraveldottv className="icon"/></li>
                <li onClick={GoHome}>HOME</li>
                <li onClick={GoAbout}>BOOKING</li>
                <li onClick={GoContact}>CONTACT</li>
            </ul>
                </nav>
            </header>
            </div>
            <form class="c1" onSubmit={handleSubmit} action=" " style={{borderWidth:'2mm',backgroundColor:'white', border: '1px solid #ccc', padding: '20px', borderRadius: '5px' }}>
         <h2 class="c2">LOGIN</h2><hr></hr>
        <div class="div2"style={{paddingBottom:'10px'}}>
          <label style={{backgroundColor:'lightgrey'}}>Email:</label><br></br>
          <input   required  class="c4"   type="email"  color='white' placeholder='enter email' value={email}  onChange={(e)=>setEmail(e.target.value)}/><br></br>
        </div>
        <div class="div3" style={{paddingBottom:'20px'}}>
          <label style={{backgroundColor:'lightgrey'}}>Password:</label><br></br>
          <input  required  class="c5" type="password"  color='white' placeholder='enter password' value={password} onChange={(e) => setPassword(e.target.value)}/><br></br>
        </div >
        <div style={{backgroundColor:'lightgrey'}}>
            <a href='#'  style={{backgroundColor:'lightgrey'}} >forgot password?</a>
        </div>
        <Button variant="contained" href="/Sign">LOGOUT</Button>
      </form>
      </div>   
    )
}
export default Logout;