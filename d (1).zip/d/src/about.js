import React, { useState } from "react";
import {SiYourtraveldottv} from 'react-icons/si';
import { useNavigate } from 'react-router-dom';
import Button from '@mui/material/Button';

let About=()=>{
    let n=useNavigate()

    let GoHome=()=>{
        n('/')
    }
    let GoAbout=()=>{
        n('/About')
    }
    let GoContact=()=>{
        n('/Contact')
    }
    
    return(
        
        <div id="div2">
            <header>
                <nav>
                    <ul>
                    <li><SiYourtraveldottv className="icon"/></li>
                        <li onClick={GoHome}>HOME</li>
                        <li onClick={GoAbout}>BOOKING</li>
                        <li onClick={GoContact}>CONTACT</li>
                    </ul>
                </nav>
            </header>
            <h1>Flight Booking</h1>
            <center>
                <img src="https://tse3.mm.bing.net/th?id=OIP.FnJ80gZYKHJ0x0liQiZ-0AHaEx&pid=Api&P=0&h=180"></img>
               <u><h1>BOOKING INFORMATION</h1><br></br></u>
                From:<input type="text"></input><br></br><br></br>
                To:  <input type="text"></input><br></br><br></br>
                Departure Date:<input type="date"></input><br></br><br></br>
                Returning Date:<input type="date"></input><br></br><br></br>
                Adults <input type="number"></input>
                Childrens <input type="number"></input><br></br><br></br>
                <Button variant="contained" href="/Flight">Search</Button>
                </center>
            
        </div>
    )
}
export default About;