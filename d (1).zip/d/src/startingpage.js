import React from 'react';

const Startingpage = () => {
  return (
    <div>
      <h1>i am starting page</h1>
    </div>
  )
}

export default Startingpage;
