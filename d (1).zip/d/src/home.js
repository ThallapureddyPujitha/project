import React from "react";
import './index.css';
import {SiYourtraveldottv} from 'react-icons/si';
import { useNavigate } from "react-router-dom";

let Home=()=>{
    const n=useNavigate();
    let GoHome=()=>{
        n('/')
    }
    let GoAbout=()=>{
        n('/About')
    }
    let GoContact=()=>{
        n('/Contact')
    }
    return(
        <div id="div1">
            <header>
            <nav>
            <ul>
                <li><SiYourtraveldottv className="icon"/></li>
                <li onClick={GoHome}>HOME</li>
                <li onClick={GoAbout}>BOOKING</li>
                <li onClick={GoContact}>CONTACT</li>
            </ul>
            </nav>
            </header>
            <center>
            <h1>Create Ever-lasting </h1>
            <h1>Memories With Us</h1>
            <img src="https://usagif.com/wp-content/uploads/gif/have-a-anice-flight-7.gif.webp"></img>
            <h2><li>Travel requirements for dubai</li></h2>
            <p>Find help with booking and travel plans,see what to expect <br></br>along the journey to your favourite destinations!</p>
            <h2><li>Chaoffeur services at your arraival</li></h2>
            <p>Find help with booking and travel plans,see what to expect <br></br>along the journey to your favourite destinations!</p>
            <h2><li>Multi-risk travel insurence</li></h2>
            <p>Find help with booking and travel plans,see what to expect <br></br>along the journey to your favourite destinations!</p>
            <h1>Travel to make Memories all <br></br>around the world</h1>
            <img style={{height:'7cm',width:'20cm'}}src="https://cdn.travelpulse.com/images/99999999-9999-9999-9999-999999999999/fe2245ab-ce0c-58e4-504e-299cd3110a77/630x355.jpg"></img>
            <h1>Unaccompanied Minor Launge</h1>
            <img src="https://cdn.loyaltylobby.com/wp-content/uploads/2016/06/AA-UM-Incident.jpg"></img>
            <h2><li>Help through the airport</li></h2>
            <p>You can also call airlines from Your phone and book a flight ticket to one of your favorite <br></br>destinations.</p>
            <h2><li>Care on the flight</li></h2>
            <p>You can also call airlines from Your phone and book a flight ticket to one of your favorite <br></br>destinations.</p>
            </center>
        </div>
        
    )
}
export default Home;
