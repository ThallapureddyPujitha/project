import React from "react";
import Button from '@mui/material/Button';



let Logining=()=>{
    
    return(
   
            <div id="body">   
            <center>
            <u><header>LOGIN PAGE</header></u><br></br>
            Firstname: <input type="text" placeholder=" enter the firstname" required /><br></br><br></br>
            Lastname:<input type="text" placeholder=" enter the lastname" required /><br></br><br></br>
            Date of birth:<input type="text" placeholder="enter the date of birth" required /><br></br><br></br>
            Moblie No:<input type="text" placeholder="enter the moblie number" required /><br></br><br></br>
            Address:<input type="text" placeholder="enter the address"  required /><br></br><br></br>               
            Email: <input type="text" placeholder="enter the Email" required /><br></br><br></br>
            Password: <input type="text" placeholder="enter the Password" required /><br></br><br></br>
            <Button variant="contained" href="/Home">Submit</Button>
            </center>
            </div>
    
    )

}

export default Logining;