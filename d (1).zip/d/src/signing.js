import React from 'react';
import './signing.css';
import './tosign.js';
import Button from '@mui/material/Button';



const Signing = () => {
  return (
    <div>
      <main id="mainpage">
        <h1>Simple Tabs</h1>
        <div class="tabs_container">
            <button class="btn active" id="flex-item-1">Sign Up</button>
            <button class="btn " id="flex-item-2">Login</button>
        </div>
        <div class="page_tabs">
            <div class="tab" id="signup_div">
                <form>
                    <label for="username" class="label">Username:</label><br></br>
                    <input type="text" id="username" class="inputs" required></input><br></br>
                    <label for="password" class="label">Password:</label><br></br>
                    <input type="password" id="password" class="inputs" required></input><br></br>
                    <label for="confrimpassword" class="label">Confirm Password:</label><br></br>
                    <input type="password" id="confirmpassword" class="inputs" required></input><br></br>
                    <Button variant="contained" href='/Login in'>Login</Button>
                </form>
            </div>
            
            <div class="tab" id="login_div">
                <form>
                    <label for="username" class="label">Username:</label><br></br>
                    <input type="text" id="username" class="inputs" required></input><br></br>
                    <label for="password" class="label">Password:</label><br></br>
                    <input type="password" id="password" class="inputs" required></input><br></br>
                    <Button variant="contained" href='/Home'>Submit</Button>
                </form>   
            </div>
        </div>
    </main>
    </div>
  )
}

export default Signing;
