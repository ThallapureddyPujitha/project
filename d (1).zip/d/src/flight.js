import React, { useState } from 'react';
import Button from '@mui/material/Button';


// Flight data
const fligths = [
  { id: 1, title: 'Flight 1', seats: 50 },
  { id: 2, title: 'Flight 2', seats: 60 },
  { id: 3, title: 'Fligth 3', seats: 50 },
  // Add more flight objects as needed
];

const Bujji = () => {
  const [selectedFlight, setSelectedFlight] = useState(null);
  const [selectedSeats, setSelectedSeats] = useState([]);

  const handleFlightSelect = (flightId) => {
    setSelectedFlight(flightId);
    setSelectedSeats([]);
  };

  const handleSeatSelect = (seat) => {
    if (selectedSeats.includes(seat)) {
      setSelectedSeats(selectedSeats.filter((selectedSeat) => selectedSeat !== seat));
    } else {
      setSelectedSeats([...selectedSeats, seat]);
    }
  };

  const handleFormSubmit = (event) => {
    event.preventDefault();
    // Handle form submission and booking logic here
    console.log('Form submitted!');
  };

  const seatPrice = 1500;
  const totalPrice = selectedSeats.length * seatPrice;

  return (
    <div>
      <h1>Flight Ticket Booking</h1>
      <div>
        <h2>Select a flight:</h2>
        {fligths.map((flight) => (
          <button key={flight.id} onClick={() => handleFlightSelect(flight.id)}>
            {flight.title}
          </button>
        ))}
      </div>
      {selectedFlight && (
        <div>
          <h2>Select seats:</h2>
          <div>
            Seats available: {fligths.find((flight) => flight.id === selectedFlight).seats}
          </div>
          <div>
            {Array.from({ length: fligths.find((flight) => flight.id === selectedFlight).seats }, (_, index) => (
              <button
                key={index + 1}
                onClick={() => handleSeatSelect(index + 1)}
                disabled={selectedSeats.includes(index + 1)}
              >
                {index + 1}
              </button>
            ))}
          </div>
          <div>
            <h2>Selected seats:</h2>
            {selectedSeats.map((seat) => (
              <span key={seat}>{seat}, </span>
            ))}
          </div>
          <form onSubmit={handleFormSubmit}>
            <h2>Enter your details:</h2>
            <label>
              Name:
              <input type="text" />
            </label>
            <br />
            <label>
              Email:
              <input type="email" />
            </label>
            <br />
            <h3>Total Price: Rs. {totalPrice}</h3>
            <Button variant="contained" href="/About">Book</Button>

          </form>
        </div>
      )}
    </div>
  );
};

export default Bujji;